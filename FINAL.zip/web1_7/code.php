<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MacHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Կցել style.css ֆայլը -->
    <link rel="stylesheet" href="style.css">
  </head>

  <body>
    <?php include_once 'navbar.php'; ?> 
  
  </body>
</html>

<br>
<br>
<br>
<br>
    <h2 style="text-align: center;">Welcome to the MacHub website for the latest Apple products!</h2>

   <main class="container my-5">
 
  <div id="carouselExample" class="carousel slide w-75 m-auto">
    <div class="carousel-inner">
   
      <div class="carousel-item active">
        <iframe width="100%" height="400" src="https://www.youtube.com/embed/e6T34u51MaA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="object-fit: contain;"></iframe>
      </div>

   
      <div class="carousel-item">
        <img src="https://i5.walmartimages.com/seo/CTO-Apple-MacBook-Air-13-in-M3-8C-CPU-10C-GPU-16GB-256GB-Space-Gray-30W-Spring-2024-Z1B60016J_8ad6039e-9709-4d6d-8fa0-5434d76a18e9.9e6c92229abbb854bbb9d29f214d9162.jpeg?odnHeight=612&odnWidth=612&odnBg=FFFFFF" class="d-block w-100" alt="MacBook Air Image 1" style="height: 400px; object-fit: contain;">
      </div>

 
      <div class="carousel-item">
        <img src="https://www.technoworld.com/media/catalog/product/cache/941012141e93b216d64d157444571b98/z/1/z175-005-ukuk_1.jpg" class="d-block w-100" alt="MacBook Image 2" style="height: 400px; object-fit: contain;">
      </div>

   
      <div class="carousel-item">
        <img src="https://www.scan.co.uk/images/products/xlarge/3371968-xl-a.jpg" class="d-block w-100" alt="MacBook Image 3" style="height: 400px; object-fit: contain;">
      </div>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</main>

<br>


    
      <div class="accordion" id="accordionExample">
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              Frequently asked questions #1
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              1. How can I place an order? 
              <br>
              To place an order, simply choose your desired product, click "Add to Cart," and follow the checkout instructions to enter your shipping and payment details.
            </div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
              Frequently asked questions #2
            </button>
          </h2>
          <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              2. Are the products new or used?
              <br>
              We only sell brand-new, sealed products sourced directly from official distributors.
            </div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
              Frequently asked questions #3
            </button>
          </h2>
          <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              3. How long does delivery take?    
              <br> 
              Delivery within Yerevan usually takes 1 business day. For regions outside Yerevan, delivery takes 2–3 business days.
            </div>
          </div>
        </div>
      </div>

    </main>

    <?php include_once 'footer.php'; ?> <!-- Footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
    
  </body>
</html>


