<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MacHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  </head>
  <body>
     <?php include_once 'navbar.php'; ?>

     <main class="container my-5">
      <h1 style="text-align: center;">REGISTRATION</h1>
      <br>

      <form class="row g-3">
        <div class="col-md-6">
          <label for="inputEmail4" class="form-label">Email</label>
          <input type="email" class="form-control" id="inputEmail4">
        </div>

        <div class="col-md-6">
          <label for="inputPassword4" class="form-label">Password</label>
          <input type="password" class="form-control" id="inputPassword4">
        </div>

        <div class="col-12">
          <label for="inputName" class="form-label">Name</label>
          <input type="text" class="form-control" id="inputName">
        </div>

        <div class="col-12">
          <label for="inputSurname" class="form-label">Surname</label>
          <input type="text" class="form-control" id="inputSurname">
        </div>

        <div class="col-12">
          <label class="form-label d-block">Gender</label>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="radioMale" value="male">
            <label class="form-check-label" for="radioMale">Male</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="radioFemale" value="female" checked>
            <label class="form-check-label" for="radioFemale">Female</label>
          </div>
        </div>

        <!-- Month -->
        <div class="col-md-4">
          <label for="inputMonth" class="form-label">Month</label>
          <select id="inputMonth" name="month" class="form-select">
            <?php
              $months = [
                "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
              ];

              foreach ($months as $month) {
                echo "<option value='".$month."'>".$month."</option>";
              }
            ?>
          </select>
        </div>

        <!-- Day -->
        <div class="col-md-4">
          <label for="inputDay" class="form-label">Day</label>
          <select id="inputDay" name="day" class="form-select">
            <?php
              for ($x = 1; $x <= 31; $x++) {
                echo "<option value='".str_pad($x, 2, '0', STR_PAD_LEFT)."'>".str_pad($x, 2, '0', STR_PAD_LEFT)."</option>";
              }
            ?>
          </select>
        </div>

        <!-- Year -->
        <div class="col-md-4">
          <label for="inputYear" class="form-label">Year</label>
          <select id="inputYear" name="year" class="form-select">
            <?php
              $currentYear = date("Y");
              for ($x = 1900; $x <= $currentYear; $x++) {
                echo "<option value='".$x."'>".$x."</option>";
              }
            ?>
          </select>
        </div>

        <div class="col-12">
          <button type="submit" class="btn btn-primary">Sign in</button>
        </div>
      </form>
    </main>

  </body>
</html>
