<?php 
var_dump($_POST);


echo $_POST ["lastname"];

$f_name = $_POST ['f_name'];
$f_name = $_POST ['l_name'];

if(isset($_POST['register'])
	header("location:myaccount.php");
 ?>