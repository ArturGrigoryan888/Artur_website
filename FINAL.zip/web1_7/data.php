<?php 

$product1 = array (
	'id' =>0,
"name" => "Apple MacBook Air 15 ",
"image" => "https://procare.gr/10611-large_default/apple-macbook-pro-13-m1-chip-8-core-cpu-8-core-gpu-8gb-512gb-space-gray-myd92.jpg",
"price"=> 999,
"desc" => "Featuring the powerful Apple M4 chip, 16GB RAM, and 256GB SSD in a sleek Midnight design.",
);

$product2 = array (
	'id' =>1,
"name" => "Apple MacBook Air 16 ",
"image" => "https://5.imimg.com/data5/SELLER/Default/2022/8/FI/BS/UH/9653287/apple-macbook-pro-14-16-inch-10182021-big-jpg-large.jpg",
"price"=> 999,
"desc" => "Featuring the powerful Apple M4 chip, 16GB RAM, and 256GB SSD in a sleek Midnight design.",
);

$product3 = array (
	'id' =>2,
"name" => "Apple MacBook Air 17 ",
"image" => "https://procare.gr/10611-large_default/apple-macbook-pro-13-m1-chip-8-core-cpu-8-core-gpu-8gb-512gb-space-gray-myd92.jpg",
"price"=> 999,
"desc" => "Featuring the powerful Apple M4 chip, 16GB RAM, and 256GB SSD in a sleek Midnight design.",
);

$product4 = array (
	'id' =>3,
"name" => "Apple MacBook Air 18 ",
"image" => "https://9to5mac.com/wp-content/uploads/sites/6/2021/10/MacBook-Pro-2021.jpg?quality=82&strip=all&w=1024",
"price"=> 999,
"desc" => "Featuring the powerful Apple M4 chip, 16GB RAM, and 256GB SSD in a sleek Midnight design.",
);



$products = array($product1, $product2, $product3, $product4);



 ?>